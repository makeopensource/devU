#!/bin/bash

python3 grader.py